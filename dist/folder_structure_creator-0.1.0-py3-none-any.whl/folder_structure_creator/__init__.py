# folder_structure_creator/__init__.py

from .fstruct import create_folder_structure_from_file

__all__ = ["create_folder_structure_from_file"]
